# LedgerWash 1.0 beta 2

LedgerWash 在固定的 Git 版本上檢查 agent 任務帳本。它會找出能從紀錄核對的問題，例如交接收據引用不到檔案、檔案內容與登錄的雜湊不同。掃描在本機執行，唯讀、離線，不需模型或 API key。完整自洽的偽造帳本仍可能通過掃描。

這次試用收集安裝體驗、輸出是否容易判讀，以及工具在獨立專案上的表現。套件版本為 `1.0.0b2`，採用 Spec 6。正式版驗收仍在進行。

## 安裝

需要 Python 3.11 以上與 Git。解壓縮後，在含有 `.whl` 的資料夾開啟終端機。Linux 或 WSL 也可用 `python3 -m zipfile -e LedgerWash-1.0.0b2-beta.zip ledgerwash-beta` 解壓，再執行 `cd ledgerwash-beta`。下列指令直接安裝隨附的檔案。

**Windows PowerShell**

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --no-index --no-deps ./ledgerwash-1.0.0b2-py3-none-any.whl
.\.venv\Scripts\python.exe -m ledgerwash --version
```

**macOS 或 Linux**

```sh
python3 -m venv .venv
.venv/bin/python -m pip install --no-index --no-deps ./ledgerwash-1.0.0b2-py3-none-any.whl
.venv/bin/python -m ledgerwash --version
```

版本輸出應為 `ledgerwash 1.0.0b2 (spec 6)`。

## 掃描隨附範例

先執行 `git clone ./demo.bundle demo`。這是可以離線複製的合成帳本，裡面的任務和收據專供練習使用。

Windows 執行下列指令。macOS 或 Linux 請把每行最前面的 `.\.venv\Scripts\python.exe` 換成 `.venv/bin/python`。

```powershell
.\.venv\Scripts\python.exe -m ledgerwash qualify
.\.venv\Scripts\python.exe -m ledgerwash scan ./demo --summary
```

範例提供了 `demo-base` 與 `demo-head` 兩個標記。要比較兩次變更，可先保存舊版本的基準，再掃描新版。

```powershell
.\.venv\Scripts\python.exe -m ledgerwash baseline ./demo --at demo-base --out baseline.json
.\.venv\Scripts\python.exe -m ledgerwash scan ./demo --at demo-head --baseline baseline.json --summary
```

`GROUPS` 依規則與嚴重度分組。`new` 是這次沒有被 baseline 涵蓋的項目，`baselined` 是符合先前基準的項目。

| 摘要中的欄位 | 如何判讀 |
| --- | --- |
| `scan verdict` | 本次命令的結論。退出碼 0 表示掃描通過，1 表示掃描完成且有阻擋條件，2 表示輸入或執行錯誤。 |
| `finding verdict` | 看新增發現是否達到阻擋門檻，預設是 high。另一個可能的阻擋原因會列在 coverage。 |
| `coverage` | 顯示證據本身的完整性。基準可接受一項已知 mismatch，但該項仍是 mismatch。因此可能同時看到 `complete=false` 與退出碼 0。 |
| `verification` | 顯示證據驗證狀態。`UNKNOWN` 代表仍有缺口。例如 `self_signing` 表示無從獨立證明執行真實性；掃描可以在這種情況下通過。 |

大帳本可用 `--summary --progress` 在 stderr 看目前執行階段。加 `--details` 展開每筆驗證缺口；加 `--out findings.json` 另存完整機器輸出。`release-gate` 供維護者在 LedgerWash 原始碼倉檢查發布證據。檢查本機安裝使用上方的 `qualify`。

## 改用自己的帳本

先看 [帳本格式與可執行範例](docs/beta/ledger-format.md)。內含可複製的 task、receipt、JSON Schema，以及一個 coverage 完整、可從零重跑的範例。內建 reader 讀取指定 Git commit 中的 `governance/tasks/T-*.json` 與 `evidence/task-operations/*.json`。有這兩類正式紀錄後，將 `./demo` 換成你的本機 Git repo。

## 回報試用體驗

請到[公開試用回報入口](https://github.com/taipei49314/taipei49314.github.io/issues/new?title=%5BLedgerWash%20beta%5D%20)，或回覆你看到的 X 招募貼文。附上作業系統、Python 與 LedgerWash 版本、操作步驟、預期與實際結果。若有卡點，貼一行已去識別的錯誤訊息即可。若願意提供獨立帳本做盲測，先聯絡維護者安排封存，將原始資料與標註答案留在自己手上。
