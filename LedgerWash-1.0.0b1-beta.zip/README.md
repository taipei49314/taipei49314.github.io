# LedgerWash 1.0 beta 1

LedgerWash 在固定的 Git 版本上檢查 agent 任務帳本。它會找出能從紀錄核對的問題，例如交接收據引用不到檔案、檔案內容與登錄的雜湊不同。掃描在本機執行，唯讀、離線，不需模型或 API key。完整自洽的偽造帳本仍可能通過掃描。

這次試用收集安裝體驗、輸出是否容易判讀，以及工具在獨立專案上的表現。套件版本為 `1.0.0b1`，採用 Spec 6。正式版驗收仍在進行。

## 安裝

解壓縮試用包，在含有 `.whl` 的資料夾開啟終端機。需要 Python 3.11 以上與 Git。下列指令從下載的檔案安裝，不需從套件索引下載 LedgerWash。

**Windows PowerShell**

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --no-index --no-deps ./ledgerwash-1.0.0b1-py3-none-any.whl
.\.venv\Scripts\python.exe -m ledgerwash --version
```

**macOS 或 Linux**

```sh
python3 -m venv .venv
.venv/bin/python -m pip install --no-index --no-deps ./ledgerwash-1.0.0b1-py3-none-any.whl
.venv/bin/python -m ledgerwash --version
```

版本輸出應為 `ledgerwash 1.0.0b1 (spec 6)`。

## 掃描隨附範例

先執行 `git clone ./demo.bundle demo`。這是可以離線複製的合成帳本，裡面的任務和收據專供練習使用。

Windows 執行下列指令。macOS 或 Linux 請把每行最前面的 `.\.venv\Scripts\python.exe` 換成 `.venv/bin/python`。

```powershell
.\.venv\Scripts\python.exe -m ledgerwash qualify
.\.venv\Scripts\python.exe -m ledgerwash scan ./demo --summary
```

範例提供了 `demo-base` 與 `demo-head` 兩個標記。要比較兩次變更，可先保存舊版本的基準，再掃描新版。

```powershell
.\.venv\Scripts\python.exe -m ledgerwash baseline ./demo --at demo-base --out baseline.json
.\.venv\Scripts\python.exe -m ledgerwash scan ./demo --at demo-head --baseline baseline.json --summary
```

`GROUPS` 依規則與嚴重度分組。`new` 是這次沒有被 baseline 涵蓋的項目，`baselined` 是符合先前基準的項目。退出碼 0 代表通過這次掃描門檻，1 代表掃描完成且發現阻擋條件，2 代表輸入或執行錯誤。

## 改用自己的帳本

將 `./demo` 換成你的本機 Git repo。內建 reader 讀取指定 commit 中的 `governance/tasks/T-*.json` 及 `evidence/task-operations/*.json`。請保留 Git 歷史。沒有這兩類資料的普通程式碼 repo 不適合用來驗證帳本效果。

## 回報試用體驗

請回覆招募貼文，附上作業系統、Python 與 LedgerWash 版本、嘗試的步驟、你預期看到什麼、實際看到什麼。若有卡點，貼一行已去識別的錯誤訊息即可。若願意提供獨立帳本做盲測，先聯絡維護者安排封存，將原始資料與標註答案留在自己手上。
